from utils import get_data, plot_metrics, normalize
from model import MultiClassSVM, PCA
from typing import Tuple


def get_hyperparameters() -> Tuple[float, int, float]:
    
    learning_rate=0.00008
    n_iters = 100000
    c = 10
    return [learning_rate, n_iters, c]


def main() -> None:
    # hyperparameters
    learning_rate, num_iters, C = get_hyperparameters()

    # get data
    X_train, X_test, y_train, y_test = get_data()

    # normalize the data
    X_train, X_test = normalize(X_train, X_test)

    metrics = []
    for k in [5, 10, 20, 50, 100, 200, 500]:
        # reduce the dimensionality of the data
        pca = PCA(n_components=k)
        X_train1 = pca.fit_transform(X_train)
        X_test1 = pca.transform(X_test)

        #print(X_train1.shape ,X_train.shape,X_test1.shape,X_test.shape)

        #create a model
        svm = MultiClassSVM(num_classes=10)

        # fit the model
        svm.fit(
            X_train1, y_train, C=C,
            learning_rate=learning_rate,
            num_iters=num_iters,
        )

    #     # evaluate the model
        accuracy = svm.accuracy_score(X_test1, y_test)

        #print("accuracy",accuracy)
        precision = svm.precision_score(X_test1, y_test)
        #print("precision", precision)
        recall = svm.recall_score(X_test1, y_test)
        #print("recall",recall)
        f1_score = svm.f1_score(X_test1, y_test, precision, recall)
        #print("f1_score",f1_score )

        metrics.append((k, accuracy, precision, recall, f1_score))

        print(f'k={k}, accuracy={accuracy}, precision={precision}, recall={recall}, f1_score={f1_score}')

    # # plot and save the results
    plot_metrics(metrics)

if __name__ == '__main__':
    main()
