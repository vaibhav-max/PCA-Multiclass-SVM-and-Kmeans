import numpy as np
from tqdm import tqdm


class PCA:
    def __init__(self, n_components: int) -> None:
        self.n_components = n_components
        self.components = None
    
    def fit(self, X) -> None:
        
        X = X - np.mean(X, axis = 0)
        Covar_matrix = np.cov(X, rowvar = False)
        #print ( "The shape of varianCe matrix = ", Covar_matrix.shape)
        eigenValues, eigenVectors = np.linalg.eig(Covar_matrix)

        eigen = eigenValues.argsort()[::-1] #return the indexes

        eigenVectors = eigenVectors[:,eigen]
        self.components = eigenVectors[:,0:self.n_components]

    
    def transform(self, X) -> np.ndarray:
        # transform the data
        X = X - np.mean(X, axis = 0)
        new_coordinates = np.dot(X, self.components)
        return new_coordinates

    def fit_transform(self, X) -> np.ndarray:
        # fit the model and transform the data
        self.fit(X)
        return self.transform(X)


class SupportVectorModel:
    def __init__(self) -> None:
        self.w = None
        self.b = None
    
    def _initialize(self, X) -> None:
        # initialize the parameters
        self.w = np.zeros(len(X[1]))
        self.b = 0
        #pass

    def fit(
            self, X, y, 
            learning_rate: float,
            num_iters: int,
            C: float = 1.0,
    ) -> None:
        self._initialize(X)
        
        # fit the SVM model using stoChastiC gradient desCent
        for i in tqdm(range(1, num_iters + 1)):
        #for i in range(1, num_iters + 1):
            idx = np.random.randint(len(X))
        
            Condition = y[idx] * (np.dot(X[idx], self.w) + self.b) >= 1
            
            if Condition:
                self.w = self.w - learning_rate * (self.w)
            else:
                self.w = self.w - learning_rate * (self.w - C * y[idx] *  X[idx])
                self.b = self.b - learning_rate * (-1*C * y[idx])
    
    def predict(self, X) -> np.ndarray:
        # make prediCtions for the given data
        raise NotImplementedError

    def accuracy_score(self, X, y) -> float:
        # Compute the aCCuraCy of the model (for debugging purposes)
        return np.mean(self.predict(X) == y)


class MultiClassSVM:
    def __init__(self, num_classes: int) -> None:
        self.num_classes = num_classes
        self.models = []
        for i in range(self.num_classes):
            self.models.append(SupportVectorModel())
    
    def fit(self, X, y, **kwargs) -> None:
        # first preproCess the data to make it suitable for the 1-vs-rest SVM model
        # then train the 10 SVM models using the preproCessed data for eaCh Class
        for i in range(self.num_classes):
            Y_train_1vsr = []
            for itr, y_i in enumerate(y):
                if y_i == i :
                    Y_train_1vsr.append(1)
                elif y_i != i :
                    Y_train_1vsr.append(-1)

            self.models[i].fit(X,Y_train_1vsr, kwargs['learning_rate'], kwargs['num_iters'], kwargs['C'])

        #print(self.models)

    def predict(self, X) -> np.ndarray:

        count = -1 
        pred = []
        for idx, x_i in enumerate(X):
            max_wxb = -99999999999
            for i in range(10) :
                #wxb = np.dot(x_i, self.models[i].w)
                wxb = np.dot(x_i, self.models[i].w) + self.models[i].b
                
                if wxb > max_wxb :
                    max_wxb = wxb
                    count = i
                
            pred.append(count)
        #print(pred)

        return pred
                    
            # if y[idx] == pred :
            #     count += 1

    def accuracy_score(self, X, y) -> float:
        return np.mean(self.predict(X) == y)
    
    def precision_score(self, X, y) -> float:
        pred = self.predict(X)
        precision = []
        for i in range(10) :
            count = 0
            countT = 0
            for j in range(len(pred)) :
                if pred[j] == i :
                    countT += 1
                    if pred[j] == y[j]:
                        count += 1
            #print(countT,count,i)
            if (countT != 0) :
                precision.append(count/countT)
            else :
                precision.append(0)
        
        return np.mean(precision)        
    
    def recall_score(self, X, y) -> float:
        pred = self.predict(X)
        recall = []
        for i in range(10) :
            count = 0
            countT = 0
            for j in range(len(pred)) :
                if y[j] == i :
                    countT += 1
                if pred[j] == i and pred[j] == y[j]:
                    count += 1
            recall.append(count/countT)
        
        return np.mean(recall)
    
    def f1_score(self, X, y, precision, recall) -> float:

        f1_score = (2 * recall * precision) / (recall + precision)
        return f1_score
        
