import numpy as np

class KMeans:
    def __init__(self, k : int, epsilon : float = 1e-6) -> None:
        self.num_clusters = k
        self.cluster_centers = None
        self.epsilon = epsilon
    
    def fit(self, X: np.ndarray, max_iter: int = 100) -> None:
        # Initialize cluster centers (need to be careful with the initialization,
        # otherwise you might see that none of the pixels are assigned to some
        # of the clusters, which will result in a division by zero error)
        self.centroids = []
        
        # Initialize centroids randomly
        for i in range(self.num_clusters):
            centroid = X[np.random.choice(range(len(X)))]
            self.centroids.append(centroid)

        #print(self.centroids)
        count1 = 0
        for _ in range(max_iter):
            # Assign each sample to the closest prototype
            clusters = [[] for _ in range(self.num_clusters)]
            for x in X:
                distances = [np.linalg.norm(x - c) for c in self.centroids]
                cluster_index = np.argmin(distances)
                clusters[cluster_index].append(x)
 
            count1 += 1
            #print(len(clusters[0])+len(clusters[1])+len(clusters[2])+len(clusters[3])+len(clusters[4]))
            #print(count1)
            # Update prototypes
            # Calculate the new centroid for each cluster
            new_centroids = []
            for cluster in clusters:
                new_centroid = np.mean(cluster, axis=0)
                new_centroids.append(new_centroid)
            
            # Check if centroids have converged
            if np.allclose(self.centroids, new_centroids, atol = self.epsilon):
                break
            
            self.centroids = new_centroids

    
    def predict(self, X: np.ndarray) -> np.ndarray:
        # Predicts the index of the closest cluster center for each data point
        clusters = [[] for _ in range(self.num_clusters)]
        predicted_X = np.zeros(X.shape)
        count = 0
        for x in X:
            distances = [np.linalg.norm(x - c) for c in self.centroids]
            cluster_index = np.argmin(distances)
            clusters[cluster_index].append(x)
            predicted_X[count] = self.centroids[cluster_index]
            #predicted_X[count] = 0
            count += 1
        return predicted_X
    
    def fit_predict(self, X: np.ndarray, max_iter: int = 100) -> np.ndarray:
        self.fit(X, max_iter)
        return self.predict(X)
    
    def replace_with_cluster_centers(self, X: np.ndarray) -> np.ndarray:
        # Returns an ndarray of the same shape as X
        # Each row of the output is the cluster center closest to the corresponding row in X
        # predicted_X = np.zeros(X.shape)
        predicted_X = self.predict(X)

        return predicted_X