from model import KMeans
from utils import get_image, show_image, save_image, error
from matplotlib import pyplot as plt


def main():
    # get image
    image = get_image(r'C:\Users\vaibh\OneDrive\Desktop\IISc\2 sem\ML\Asst2 Vaibhav 20965\image.jpg')
    img_shape = image.shape
    #print(img_shape)

    # reshape image
    image = image.reshape(image.shape[0] * image.shape[1], image.shape[2])

    #print(image[0])

     # create model
    num_clusters = 2 # CHANGE THIS
    kmeans = KMeans(num_clusters)

    # fit model
    kmeans.fit(image)

    # # replace each pixel with its closest cluster center
    #image = kmeans.replace_with_cluster_centers(image)
    image_clustered = kmeans.replace_with_cluster_centers(image)
    # reshape image
    #image_clustered = image.reshape(img_shape)

    #print(image.shape,'hello', image_clustered.shape)
    # Print the error
    print('MSE:', error(image, image_clustered))

    # show/save image
    # show_image(image)
    image_clustered = image_clustered.reshape(img_shape)
    
    save_image(image_clustered, f'image_clustered_k{num_clusters}.jpg')



if __name__ == '__main__':
    main()
